var homePageViewModel = {
    data: {},
    generic: {
        wrapperContainerId: "",
        wrapperTemplateUrl: "",
        templateUrl: "js/views/partials/homePageView.ejs",
        containerId: "app_container",
    }
}
export default homePageViewModel;