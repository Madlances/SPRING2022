/* App View Model-contains application level meta data */
import teamViewModel from "./teamViewModel.js";
var appViewModel = {
  viewModel: teamViewModel,
};
export default appViewModel;
