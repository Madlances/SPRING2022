var mockTeamData = [
  {
    id: 0,
    name: "Ghost Hunters",
    coachName: "Luigi",
    coachPhone: "(666)-666-6666",
    coachEmail: "test@test.test",
    numPlayers: 1,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 1,
    name: "The Pink Puffs",
    coachName: "Kirby",
    coachPhone: "(123)-456-7890",
    coachEmail: "test@test.test",
    numPlayers: 2,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 2,
    name: "Buffet's Bane",
    coachName: "Pacman",
    coachPhone: "(555)-555-5555",
    coachEmail: "test@test.test",
    numPlayers: 3,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 3,
    name: "It's a Mii, Mario!",
    coachName: "Mario",
    coachPhone: "(232)-323-2323",
    coachEmail: "test@test.test",
    numPlayers: 2,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 4,
    name: "Echoes",
    coachName: "Lucas",
    coachPhone: "(111)-111-1111",
    coachEmail: "test@test.test",
    numPlayers: 2,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 5,
    name: "Plant Gang!",
    coachName: "Bayonetta",
    coachPhone: "(454)-545-4545",
    coachEmail: "test@test.test",
    numPlayers: 2,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },

  {
    id: 6,
    name: "Corrupted Visions",
    coachName: "Samus",
    coachPhone: "(999)-999-9999",
    coachEmail: "test@test.test",
    numPlayers: 2,
    notes: "notes!",
    teamPhoto: "images/Smash_Ball.png",
  },
];
export default mockTeamData;
