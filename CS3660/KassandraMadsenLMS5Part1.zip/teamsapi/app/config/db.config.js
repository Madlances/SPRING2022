module.exports = {
    HOST: 'jenson-mysql.c8qwuofu4md8.us-east-1.rds.amazonaws.com',
    USER: 'kennyjay',
    PASSWORD: 'mysqluser',
    DB: 'km_teams_sp22',
};
