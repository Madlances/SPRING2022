package madsen;

public class XXCircle {

    /**
     * This function will set the location of the shape (for now we are just printing out a statement to indicate that)
     */
    public void setLocation() {
        System.out.println("You have set the location of the shape Circle");
    }

    /**
     * This function will get the location of the shape (for now we are just printing out a statement to indicate that)
     */
    public void getLocation() {
        System.out.println("You have the location of the shape Circle");
    }

    /**
     * This function will display the shape (for now we are just printing out a statement to indicate that)
     */
    public void displaylt() {
        System.out.println("You have the shape Circle displayed");
    }

    /**
     * This function will fill the shape (for now we are just printing out a statement to indicate that)
     */
    public void filllt() {
        System.out.println("You have filled in the shape Circle");
    }

    /**
     * This function will set the color of the shape (for now we are just printing out a statement to indicate that)
     */
    public void setltsColor() {
        System.out.println("You have set the color of the shape Circle");
    }

    /**
     * This function will undisplay the shape (for now we are just printing out a statement to indicate that)
     */
    public void undisplaylt() {
        System.out.println("You have the shape Circle undisplayed");
    }
}