The IDE I used for this project was VS Code

**Before Running:**
1. Make sure you are in the project-3-decorator folder within the project_03_madsen_kassandra_v1 main folder when you open up a new window in visual studio or make sure you "cd" to project-3-decorator

**Running The Project in the Terminal**
To run my code in VS code I did the following commands:
1. mvn package (let it finish running through the tests)
2. Java -cp target/project-3-decorator-1.0-SNAPSHOT.jar madsen.Main
Note: running it in a different IDE will most likely use different commands to run my project than I did in VS Code)