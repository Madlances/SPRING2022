package madsen.commands;

public interface Command {
    void on();
    void off();
}
