package madsen;

/**
 * This class is one of our main Products.
 * All classes that implement this class
 * will need the display function.
 */
public interface DisplayDriver {
    public String display();
}
