package madsen;

/**
 * From original code
 */
public class CustDiner {
    String number = "38520000023237";
    int month = 11;
    int year = 2022;
}
