package madsen;

/**
 * From original code
 */
public class CustVisa {
    String number = "4321563234125";
    int month = 11;
    int year = 2022;
}
