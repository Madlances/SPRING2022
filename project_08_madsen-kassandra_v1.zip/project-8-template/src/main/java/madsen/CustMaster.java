package madsen;

/**
 * From original code
 */
public class CustMaster {
    String number = "5555555555554444";
    int month = 11;
    int year = 2022;
}
